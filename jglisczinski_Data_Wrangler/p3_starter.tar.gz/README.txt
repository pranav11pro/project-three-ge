README for Team Project Three (CS400 @ UW Madison)
==================================================

Every member of a team must have an individual README.txt file filled in in their folder on
the team's GitHub repo.

Name of submitting team member: <fill in your name here>
Wisc email of submitting team member: <fill in your wisc email here>
Team name: <fill in your team name here>
Role of submitting team member: <your role on the team>
TA: <your team's TA>
Lecturer: <your Lecturer's name>

Files written by me:
--------------------
<List ALL of the source files here that were written by you. Note that each of the
files must contain correct file headers, including your name, team, and role. List
files one per line in this section of the README.

Additional notes about the submission:
--------------------------------------
<List any additional notes for the grader here.>
